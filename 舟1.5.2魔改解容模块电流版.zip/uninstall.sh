#!/system/bin/sh

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> /data/local/tmp/battery_uninstall.log; }

log "开始卸载电池监控模块"

[ -f "/data/adb/modules/ace2pro-battery-simulator/.service.pid" ] && \
kill -9 $(cat /data/adb/modules/ace2pro-battery-simulator/.service.pid) 2>/dev/null

[ -f "/data/local/tmp/.battery_watchdog.pid" ] && \
kill -9 $(cat /data/local/tmp/.battery_watchdog.pid) 2>/dev/null

[ -f "/data/local/tmp/.dclog.pid" ] && \
kill -9 $(cat /data/local/tmp/.dclog.pid) 2>/dev/null

[ -f "/data/local/tmp/.current_monitor.pid" ] && \
kill -9 $(cat /data/local/tmp/.current_monitor.pid) 2>/dev/null

files=".battery_service.pid .battery_simulate .charge_end_time .charge_start_time .current_monitor.pid .service_start_time battery_service.log dian.log max_dian.log total_value.log .battery_watchdog.pid oppo mi dclog.log .dclog.pid battery_history.log install.log voltage_state pid_cleanup.log battery_uninstall.log"

for file in $files; do
    if [ -f "/data/local/tmp/$file" ]; then
        rm -f "/data/local/tmp/$file"
    fi
done

exit 0
