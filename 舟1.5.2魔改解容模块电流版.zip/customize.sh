#!/system/bin/sh

# 电池模拟器1.4电流版魔改解容模块安装脚本

# 检查环境
if [ "$(id -u)" != "0" ]; then
    echo "错误: 需要root权限运行此脚本"
    exit 1
fi

if [ -z "$MODPATH" ]; then
    echo "错误: MODPATH未定义，请在Magisk模块环境中运行"
    exit 1
fi

# 日志函数
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "/data/local/tmp/install.log"
}

echo "开始安装1.5.2魔改解容模块电流版..."

# 创建安装日志
echo "=== 电池模拟器安装日志 - $(date '+%Y-%m-%d %H:%M:%S') ===" > /data/local/tmp/install.log

# 备份配置文件函数
backup_config_files() {
    local backup_dir="/data/local/tmp/battery_backup"
    log "创建备份目录: $backup_dir"
    mkdir -p "$backup_dir"
    
    # 备份配置文件列表（不使用数组，使用空格分隔的字符串）
    local config_files="/data/local/tmp/dian.log /data/local/tmp/max_dian.log /data/adb/modules/ace2pro-battery-simulator/common/battery_config.sh /data/local/tmp/total_value.log /data/local/tmp/battery_history.log"
    
    log "开始备份配置文件..."
    
    # 使用for循环处理每个文件
    for config_file in $config_files; do
        if [ -f "$config_file" ]; then
            local filename=$(basename "$config_file")
            cp -f "$config_file" "$backup_dir/$filename"
            log "已备份: $config_file -> $backup_dir/$filename"
        else
            log "配置文件不存在，跳过备份: $config_file"
        fi
    done
    
    # 创建备份完成标记
    touch "$backup_dir/.backup_complete"
    log "配置文件备份完成"
    echo "原配置文件备份完成！"
}

# 执行备份
backup_config_files

# 1. 停止现有服务
log "停止现有服务..."
[ -f "/data/local/tmp/.battery_watchdog.pid" ] && kill -9 $(cat "/data/local/tmp/.battery_watchdog.pid") 2>/dev/null && log "停止watchdog服务"
[ -f "/data/local/tmp/.current_monitor.pid" ] && kill -9 $(cat "/data/local/tmp/.current_monitor.pid") 2>/dev/null && log "停止current_monitor服务"
[ -f "/data/local/tmp/.battery_service.pid" ] && kill -9 $(cat "/data/local/tmp/.battery_service.pid") 2>/dev/null && log "停止battery_service服务"
[ -f "/data/local/tmp/.dclog.pid" ] && kill -9 $(cat /data/local/tmp/.dclog.pid) 2>/dev/null && log "停止dclog服务"

# 2. 清理旧文件
log "清理旧文件..."
files=".battery_service.pid .battery_simulate .charge_end_time .charge_start_time .current_monitor.pid .service_start_time battery_service.log dian.log max_dian.log total_value.log .battery_watchdog.pid oppo mi dclog.log .dclog.pid battery_history.log install.log voltage_state pid_cleanup.log battery_uninstall.log"

for file in $files; do
    if [ -f "/data/local/tmp/$file" ]; then
        rm -f "/data/local/tmp/$file"
        log "已删除: $file"
    fi
done

# 3. 创建必要的目录和文件
log "创建必要的目录和文件..."
mkdir -p /data/local/tmp

# 创建必需的文件
FILES="/data/local/tmp/dian.log /data/local/tmp/max_dian.log /data/local/tmp/total_value.log /data/local/tmp/.current_monitor.pid /data/local/tmp/.service_start_time /data/local/tmp/.charge_start_time /data/local/tmp/.charge_end_time /data/local/tmp/.battery_service.pid /data/local/tmp/battery_service.log /data/local/tmp/install.log /data/local/tmp/dclog.log /data/local/tmp/.dclog.pid /data/local/tmp/battery_history.log"

for file in $FILES; do
    if [ ! -f "$file" ]; then
        touch "$file"
        chmod 0644 "$file"
        log "创建文件: $file"
    fi
done

# 4. 设备类型检测和品牌标识创建
log "检测设备类型并创建品牌标识..."
device_brand=$(getprop ro.product.brand 2>/dev/null | tr '[:upper:]' '[:lower:]' || echo "unknown")
device_manufacturer=$(getprop ro.product.manufacturer 2>/dev/null | tr '[:upper:]' '[:lower:]' || echo "unknown")
device_model=$(getprop ro.product.model 2>/dev/null | tr '[:upper:]' '[:lower:]' || echo "unknown")

log "设备信息: 品牌=$device_brand, 制造商=$device_manufacturer, 型号=$device_model"

# 创建品牌标识文件
if echo "$device_brand $device_manufacturer $device_model" | grep -q -E "oppo|oneplus|one|realme"; then
    log "检测为OPPO/一加/真我设备"
    echo "OPPO/一加/真我设备" > "/data/local/tmp/oppo"
    device_type="oppo"
elif echo "$device_brand $device_manufacturer $device_model" | grep -q -E "xiaomi|redmi|poco|mi"; then
    log "检测为小米设备"
    echo "小米设备" > "/data/local/tmp/mi"
    device_type="mi"
else
    log "无法确定设备类型，默认使用OPPO/一加系标识"
    echo "OPPO/一加设备" > "/data/local/tmp/oppo"
    device_type="oppo"
fi

# 5. 获取内核数据并智能转换
log "获取内核数据并智能转换..."

# !!!【修改】优先尝试OPPO/一加特定路径，失败时使用通用路径
# 定义内核路径变量
KERNEL_RM_PATH=""
KERNEL_FCC_PATH=""

# 优先尝试OPPO/一加路径
if [ -f "/sys/devices/virtual/oplus_chg/battery/battery_rm" ]; then
    KERNEL_RM_PATH="/sys/devices/virtual/oplus_chg/battery/battery_rm"
    log "使用OPPO/一加RM路径: $KERNEL_RM_PATH"
elif [ -f "/sys/devices/virtual/oplus_chg/battery/battery_fcc" ]; then
    # 如果没有RM路径但有FCC路径，也认为是OPPO设备
    KERNEL_RM_PATH="/sys/class/power_supply/battery/charge_counter"
    log "使用通用RM路径: $KERNEL_RM_PATH"
else
    KERNEL_RM_PATH="/sys/class/power_supply/battery/charge_counter"
    log "使用通用RM路径: $KERNEL_RM_PATH"
fi

# 优先尝试OPPO/一加FCC路径
if [ -f "/sys/devices/virtual/oplus_chg/battery/battery_fcc" ]; then
    KERNEL_FCC_PATH="/sys/devices/virtual/oplus_chg/battery/battery_fcc"
    log "使用OPPO/一加FCC路径: $KERNEL_FCC_PATH"
else
    KERNEL_FCC_PATH="/sys/class/power_supply/battery/charge_full"
    log "使用通用FCC路径: $KERNEL_FCC_PATH"
fi

# 获取原始内核值
kernel_rm_raw=$(cat "$KERNEL_RM_PATH" 2>/dev/null || echo "0")
kernel_fcc_raw=$(cat "$KERNEL_FCC_PATH" 2>/dev/null || echo "0")

# 如果从OPPO路径获取的值为空或0，尝试通用路径
if [ -z "$kernel_rm_raw" ] || [ "$kernel_rm_raw" = "0" ] || [ "$kernel_rm_raw" = "未知" ]; then
    if [ "$KERNEL_RM_PATH" != "/sys/class/power_supply/battery/charge_counter" ]; then
        log "OPPO/一加RM路径获取失败，尝试通用路径"
        kernel_rm_raw=$(cat "/sys/class/power_supply/battery/charge_counter" 2>/dev/null || echo "0")
    fi
fi

if [ -z "$kernel_fcc_raw" ] || [ "$kernel_fcc_raw" = "0" ] || [ "$kernel_fcc_raw" = "未知" ]; then
    if [ "$KERNEL_FCC_PATH" != "/sys/class/power_supply/battery/charge_full" ]; then
        log "OPPO/一加FCC路径获取失败，尝试通用路径"
        kernel_fcc_raw=$(cat "/sys/class/power_supply/battery/charge_full" 2>/dev/null || echo "0")
    fi
fi

log "内核原始值 - RM: ${kernel_rm_raw}, FCC: ${kernel_fcc_raw}"

# 内核值转换函数
convert_kernel_value() {
    local value=$1
    local value_name=$2  # "RM" 或 "FCC"
    
    # 检查值是否有效
    if [ -z "$value" ] || [ "$value" = "unknown" ] || [ "$value" -le 0 ] 2>/dev/null; then
        echo "0"
        return 1
    fi
    
    # 将value_name转换为大写，确保比较的一致性
    local upper_name=$(echo "$value_name" | tr '[:lower:]' '[:upper:]')
    
    # 根据value_name进行不同的处理
    case "$upper_name" in
        "RM")
            # RM处理逻辑：判断value是否大于15000
            if [ "$value" -gt 15000 ]; then
                # 大于15000，除以1000（微安时 → 毫安时）
                converted_value=$((value / 1000))
                echo "$converted_value"
            else
                # 否则直接输出
                echo "$value"
            fi
            ;;
        "FCC")
            # FCC处理逻辑：先判断value是否大于15000
            if [ "$value" -gt 15000 ]; then
                # 大于15000，除以1000（微安时 → 毫安时）
                converted_value=$((value / 1000))
                echo "$converted_value"
            elif [ "$value" -gt 200 ]; then
                # 大于200，直接输出
                echo "$value"
            else
                # 小于等于200，乘以100
                converted_value=$((value * 100))
                echo "$converted_value"
            fi
            ;;
        *)
            # 默认情况：直接输出原值
            echo "$value"
            log "警告: 未知的value_name: $value_name，使用默认处理"
            ;;
    esac
    
    return 0
}

# 使用智能转换函数转换内核值
kernel_rm=$(convert_kernel_value "$kernel_rm_raw" "RM")
kernel_fcc=$(convert_kernel_value "$kernel_fcc_raw" "FCC")

log "转换后内核值 - RM: ${kernel_rm}mAh, FCC: ${kernel_fcc}mAh"

# 6. 写入dian.log和max_dian.log
log "写入电池数据文件..."

# 写入dian.log - 使用智能转换后的值
if [ "$kernel_rm" -gt 0 ] && [ "$kernel_rm" -lt 10000 ] 2>/dev/null; then
    echo "$kernel_rm" > "/data/local/tmp/dian.log"
    log "写入dian.log: ${kernel_rm}mAh"
else
    # 使用合理的默认值
    reasonable_rm=100  # 合理的默认值
    echo "$reasonable_rm" > "/data/local/tmp/dian.log"
    log "内核RM值不合理(${kernel_rm}mAh)，使用默认值写入dian.log: ${reasonable_rm}mAh"
fi

# 写入max_dian.log - 使用智能转换后的值
if [ "$kernel_fcc" -gt 3000 ] && [ "$kernel_fcc" -lt 10000 ] 2>/dev/null; then
    echo "$kernel_fcc" > "/data/local/tmp/max_dian.log"
    log "写入max_dian.log: ${kernel_fcc}mAh"
else
    # 使用合理的默认值
    reasonable_fcc=4600  # 典型手机电池容量
    echo "$reasonable_fcc" > "/data/local/tmp/max_dian.log"
    log "内核FCC值不合理(${kernel_fcc}mAh)，使用默认值写入max_dian.log: ${reasonable_fcc}mAh"
fi

# 7. 计算并写入total_value.log
current_dian=$(cat "/data/local/tmp/dian.log" 2>/dev/null || echo "1")
total_value=$((current_dian * 1715))
echo "$total_value" > "/data/local/tmp/total_value.log"
log "写入total_value.log: ${current_dian}mAh * 1715 = ${total_value}μAs"

# 8. 设置文件权限
chmod 0666 /data/local/tmp/dian.log
chmod 0666 /data/local/tmp/max_dian.log
chmod 0666 /data/local/tmp/total_value.log
log "设置文件权限完成"

# 显示安装摘要
log "=== 安装完成摘要 ==="
log "设备类型: $device_type"
log "dian.log: $(cat /data/local/tmp/dian.log 2>/dev/null)"
log "max_dian.log: $(cat /data/local/tmp/max_dian.log 2>/dev/null)"
log "total_value.log: $(cat /data/local/tmp/total_value.log 2>/dev/null)"
log "内核原始RM值: ${kernel_rm_raw}"
log "内核原始FCC值: ${kernel_fcc_raw}"
log "转换后RM值: ${kernel_rm}"
log "转换后FCC值: ${kernel_fcc}"

echo ""
echo "安装完成!"
echo ""
echo "以下是注意事项："
echo "注意1：刷模块后手机低电量是不会关机的，出现突然关机说明电池过度放电饿死了，这种行为严重损害电池健康和寿命，出问题概不负责
注意2: 电池使用至电压过低会导致系统功能受限，出问题概不负责
注意3：安装模块后请到解容测试群查看模块更新日志，大部分问题可以从更新日志中解决，请不要随便浪费开发者的时间和精力，遇到不懂的先问群友，不行再@开发者"
echo "
快捷使用教程：安装模块重启后，进入webui-数据界面
根据个人需要修改以下三个地方：
1、电压阈值：低于电压阈值会强制显示2%电量，提醒你要充电了。
2、最大模拟电量：根据手机电池容量填写即可。
3、强制解容电量：最小让电池解容的电量。
参考值：强制解容电量 = 魔改电池容量 - 原装电池容量 - 500，优先建议调小一点
4、米系记得干掉30s，即关闭管家的PowerSaveService服务
配置修改后请重启手机

"
echo "1.5.2魔改解容模块电流版更新:"
echo "- 优化了安装脚本，安装新版本不再丢失旧版配置
- 100%电现在更耐用了
- 优化了刚开机、关机和休眠时的处理
- 优化了阈值电压的判断
- 详情日志请看群里的1.5.2更新日志公告"
exit 0
