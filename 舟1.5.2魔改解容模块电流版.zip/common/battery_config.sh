#!/system/bin/sh

# 电池监控模块配置文件
# 阈值电压       3.15V = 3,150,000微伏
export VOLTAGE_THRESHOLD=3150000
# 最大模拟电量  dian.log的最大值限制
export DIAN_MAX_THRESHOLD=6100
# 强制解容电量  默认值800mAh
export FORCE_DISCHARGE_VALUE=800

# 设备类型检测文件
export OPPO_FILE="/data/local/tmp/oppo"
export MI_FILE="/data/local/tmp/mi"

# 系统文件路径
export CURRENT_PATH="/sys/class/power_supply/battery/current_now"
export VOLTAGE_PATH="/sys/class/power_supply/battery/voltage_now"
export TEMP_PATH="/sys/class/power_supply/battery/temp"
export CAPACITY_PATH="/sys/class/power_supply/battery/capacity"
export CHARGE_FULL="/sys/class/power_supply/battery/charge_full"
export CHARGE_COUNTER="/sys/class/power_supply/battery/charge_counter"

# usb状态路径
export USB_ONLINE_PATH="/sys/class/power_supply/usb/online"
export USB_PRESENT_PATH="/sys/class/power_supply/usb/present"

# 内核电池参数路径
# 优先尝试OPPO/一加路径
if [ -f "/sys/devices/virtual/oplus_chg/battery/battery_rm" ]; then
    KERNEL_RM_PATH="/sys/devices/virtual/oplus_chg/battery/battery_rm"
else
    KERNEL_RM_PATH="/sys/class/power_supply/battery/charge_counter"
fi

# 优先尝试OPPO/一加FCC路径
if [ -f "/sys/devices/virtual/oplus_chg/battery/battery_fcc" ]; then
    KERNEL_FCC_PATH="/sys/devices/virtual/oplus_chg/battery/battery_fcc"
else
    KERNEL_FCC_PATH="/sys/class/power_supply/battery/charge_full"
fi

export KERNEL_RM_PATH
export KERNEL_FCC_PATH

# 临时文件和日志路径
export SIMULATE_PATH="/data/local/tmp/.battery_simulate"
export SERVICE_PID_FILE="/data/local/tmp/.battery_service.pid"
export WATCHDOG_PID_FILE="/data/local/tmp/.battery_watchdog.pid"
export CURRENT_MONITOR_PID_FILE="/data/local/tmp/.current_monitor.pid"
export LOG_FILE="/data/local/tmp/battery_service.log"

# 数据文件路径
export DIAN_LOG="/data/local/tmp/dian.log"
export MAX_DIAN_LOG="/data/local/tmp/max_dian.log"
export TOTAL_VALUE_LOG="/data/local/tmp/total_value.log"

# 时间记录文件
export START_TIME_FILE="/data/local/tmp/.service_start_time"
export CHARGE_START_TIME_FILE="/data/local/tmp/.charge_start_time"
export CHARGE_END_TIME_FILE="/data/local/tmp/.charge_end_time"

# 时间间隔配置（秒）
export WATCHDOG_INTERVAL=60
export LOG_LOOP_INTERVAL=3

# 电池容量相关配置
export BATTERY_DESIGN_CAPACITY=4600     # 设计容量（mAh）
export MAX_DIAN_THRESHOLD=10000        # max_dian.log最大值阈值
export MAX_DIAN_MIN_THRESHOLD=4000      # max_dian.log最小值阈值
export DIAN_DECREMENT_STEP=50          # dian.log每次减少的值
export CHARGE_DURATION_THRESHOLD=300   # 充电持续时间阈值（秒）
export CHARGE_END_SPECIAL_PERIOD=20    # 充电结束特殊时期（秒）

# 默认值配置
export DEFAULT_TEMP=250                # 默认温度值
export DEFAULT_CHARGE_FULL=4600000     # 默认充满容量
export DEFAULT_CHARGE_COUNTER=0        # 默认充电计数器
export DEFAULT_KERNEL_RM=0             # 默认内核RM值
export DEFAULT_KERNEL_FCC=0            # 默认内核FCC值
export DEFAULT_REAL_PERCENT=50         # 默认真实电量百分比