#!/system/bin/sh

MODDIR=${0%/*}

# 智能合并配置文件函数
smart_merge_config() {
    local backup_file="$1"
    local current_file="$2"
    local temp_file="/data/local/tmp/battery_config_temp.sh"
    
    # 创建临时文件
    > "$temp_file"
    
    # 读取当前配置文件的所有导出变量
    if [ -f "$current_file" ]; then
        # 提取当前文件中的所有导出变量名
        current_exports=$(grep -E '^export [A-Z_]+=' "$current_file" | sed 's/export \([A-Z_]*\)=.*/\1/')
        
        # 读取备份文件，但只保留当前文件中也存在的导出变量
        while IFS= read -r line; do
            if echo "$line" | grep -q -E '^export [A-Z_]+='; then
                # 这是导出行，提取变量名
                var_name=$(echo "$line" | sed 's/export \([A-Z_]*\)=.*/\1/')
                
                # 检查这个变量是否在当前配置文件中也存在
                if echo "$current_exports" | grep -q -w "$var_name"; then
                    # 变量在当前配置中也存在，保留备份文件中的值
                    echo "$line" >> "$temp_file"
                else
                    # 变量在当前配置中不存在，跳过（使用新版本的默认值）
                    echo "[$(date '+%Y-%m-%d %H:%M:%S')] 跳过已弃用配置: $var_name" >> "/data/local/tmp/battery_service.log"
                fi
            else
                # 非导出行（注释、函数等），直接保留
                echo "$line" >> "$temp_file"
            fi
        done < "$backup_file"
        
        # 添加当前配置文件中新增的导出变量
        while IFS= read -r line; do
            if echo "$line" | grep -q -E '^export [A-Z_]+='; then
                var_name=$(echo "$line" | sed 's/export \([A-Z_]*\)=.*/\1/')
                
                # 检查这个变量是否已经在临时文件中
                if ! grep -q -E "^export $var_name=" "$temp_file"; then
                    # 这是新增的变量，添加到临时文件
                    echo "$line" >> "$temp_file"
                    echo "[$(date '+%Y-%m-%d %H:%M:%S')] 添加新增配置: $var_name" >> "/data/local/tmp/battery_service.log"
                fi
            fi
        done < "$current_file"
        
        # 用合并后的文件替换当前配置文件
        cp -f "$temp_file" "$current_file"
        
        # 清理临时文件
        rm -f "$temp_file"
    else
        # 当前配置文件不存在，直接使用备份文件
        cp -f "$backup_file" "$current_file"
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] 使用备份配置文件（当前文件不存在）" >> "/data/local/tmp/battery_service.log"
    fi
}

# 恢复备份函数
restore_backup_if_exists() {
    local backup_dir="/data/local/tmp/battery_backup"
    
    if [ -d "$backup_dir" ]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] 检测到旧版本配置，开始恢复配置文件..." >> "/data/local/tmp/battery_service.log"
        
        # 恢复dian.log
        if [ -f "$backup_dir/dian.log" ]; then
            cp -f "$backup_dir/dian.log" "/data/local/tmp/dian.log"
        fi
        
        # 恢复max_dian.log
        if [ -f "$backup_dir/max_dian.log" ]; then
            cp -f "$backup_dir/max_dian.log" "/data/local/tmp/max_dian.log"
        fi
        
        # 恢复total_value.log
        if [ -f "$backup_dir/total_value.log" ]; then
            cp -f "$backup_dir/total_value.log" "/data/local/tmp/total_value.log"
        fi
        
        # 恢复dclog日志
        if [ -f "$backup_dir/battery_history.log" ]; then
            cp -f "$backup_dir/battery_history.log" "/data/local/tmp/battery_history.log"
        fi
        
        # 修改：智能恢复battery_config.sh
        if [ -f "$backup_dir/battery_config.sh" ]; then
            # 创建模块目录
            mkdir -p "/data/adb/modules/ace2pro-battery-simulator/common/"
            
            # 获取当前配置文件路径
            local current_config="/data/adb/modules/ace2pro-battery-simulator/common/battery_config.sh"
            local backup_config="$backup_dir/battery_config.sh"
            
            # 如果当前配置文件不存在，直接使用备份
            if [ ! -f "$current_config" ]; then
                cp -f "$backup_config" "$current_config"
            else
                # 使用智能合并
                smart_merge_config "$backup_config" "$current_config"
            fi
        fi
        
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] 备份恢复完成" >> "/data/local/tmp/battery_service.log"
    fi
}
cleanup_backup_directory() {
    local backup_dir="/data/local/tmp/battery_backup"
    
    if [ -d "$backup_dir" ]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] 清理备份文件夹: $backup_dir" >> "/data/local/tmp/battery_service.log"
        # 删除备份文件夹及其所有内容
        rm -rf "$backup_dir"
    else
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] 备份文件夹不存在，无需清理" >> "/data/local/tmp/battery_service.log"
    fi
}


# 在服务启动前恢复备份
restore_backup_if_exists

# 检查并设置二进制文件执行权限
check_and_set_permissions() {
    # 不使用数组，直接列出所有需要检查的二进制文件
    local bin_files="/system/bin/battery_simulator /system/bin/dclog /system/bin/battery_current_monitor"
    
    # 使用for循环处理每个文件
    for bin_file in $bin_files; do
        if [ -f "$bin_file" ]; then
            # 检查是否具有执行权限
            if [ ! -x "$bin_file" ]; then
                echo "[$(date '+%Y-%m-%d %H:%M:%S')] 设置执行权限: $bin_file" >> "/data/local/tmp/battery_service.log"
                chmod 755 "$bin_file"
            fi
        else
            echo "[$(date '+%Y-%m-%d %H:%M:%S')] 警告: 二进制文件不存在: $bin_file" >> "/data/local/tmp/battery_service.log"
        fi
    done
}

# 等待尝试获取电池FCC值
count=0
success_count=0
fcc_value=0

echo "[$(date '+%Y-%m-%d %H:%M:%S')] 开始获取电池FCC值..." >> "/data/local/tmp/battery_service.log"

# 最大尝试次数10次，需要成功3次
while [ $success_count -lt 3 ] && [ $count -lt 10 ]; do
    # 尝试读取FCC值
    count=$((count + 1))
    current_fcc=$(cat /sys/class/power_supply/battery/charge_full 2>/dev/null)
    
    if [ -n "$current_fcc" ] && [ "$current_fcc" -gt 0 ] 2>/dev/null; then
        # 成功获取有效值
        success_count=$((success_count + 1))
        fcc_value="$current_fcc"  # 更新最终值
        
        # 如果已经成功3次，提前退出循环
        if [ $success_count -ge 3 ]; then
            break
        fi
    else
        # 获取失败
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] ✗ 第$count次尝试失败" >> "/data/local/tmp/battery_service.log"
    fi
    
    sleep 1
done

# 记录最终结果
if [ $success_count -ge 3 ]; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] FCC值确认有效: 成功${success_count}次, 最终值: ${fcc_value}" >> "/data/local/tmp/battery_service.log"
else
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] 警告: FCC值获取未达到要求 (成功${success_count}/3次)" >> "/data/local/tmp/battery_service.log"
    # 可以在这里设置默认值或采取其他措施
    fcc_value=${fcc_value:-0}  # 如果fcc_value为空，设置为0
fi


# 记录结果
if [ -n "$fcc_value" ] && [ "$fcc_value" -gt 0 ] 2>/dev/null; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] 成功获取内核信息 (尝试次数: ${count})" >> "/data/local/tmp/battery_service.log"
else
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] 警告: 无法获取内核信息" >> "/data/local/tmp/battery_service.log"
fi

# 检查并设置二进制文件执行权限
check_and_set_permissions

sleep 1
echo "[$(date '+%Y-%m-%d %H:%M:%S')] 等待启动服务中..." >> "/data/local/tmp/battery_service.log"

sleep 3
/system/bin/battery_simulator --start-service >/dev/null 2>&1 &

sleep 3
/system/bin/dclog >/dev/null 2>&1 &

# 在恢复备份后调用清理函数
cleanup_backup_directory

exit 0
